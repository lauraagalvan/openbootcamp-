a = 100

while a >= 1:
    print("a vale", a)
    a -=1