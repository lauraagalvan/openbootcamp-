package com.example;

public class BucleFor {
    public static void main(String[] args) {


        for (int i = 0;i< 10;){

        }
    }
}
