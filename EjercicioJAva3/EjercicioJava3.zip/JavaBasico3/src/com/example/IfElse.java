package com.example;

public class IfElse {
    public static void main(String[] args) {



    int edad = 16;
    if(edad >= 18 ){
        System.out.println("Es mayor de edad");

    }else {
        System.out.println("Es menor de edad");
    }
    }
}
