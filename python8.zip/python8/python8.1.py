f = open('archivo.txt', 'w')
f.write('Leer archivo\n')
f.close()

file = open('archivo.txt', 'r+')
f.readline()
f.write('Escribo en archivo')

f.seek(0)
print(f.read())
f.close()

