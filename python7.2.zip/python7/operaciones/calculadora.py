
def suma(self, a, b):
    return a + b

def resta(self, a, b):
    return a -b

def multiplicar(self, c, d):
    return c * d

def division(self, c, d):
    return c / d