import time

hora = time.strftime('%H')
minutos = time.strftime('%H')

if int(hora) >= 19:
    print("Es hora de ir a casa")

else:
    print("Quedan{} horas y {}minutos para irnos a casa".format(18- int(hora), format(59- int(minutos))))